import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '../../../node_modules/@angular/router';
import { CookiecafeService } from '../cookiecafe.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  cookie: any;
  exception: any;
  constructor(private route: ActivatedRoute, private displayservice: CookiecafeService, private location: Location) { }

  ngOnInit() {
    this.getCookieOnId();
  }
  getCookieOnId(): void {
    let id = +this.route.snapshot.paramMap.get('id');
    console.log(id);

    this.displayservice.getCookieOnId(id).subscribe(vendor => {
      this.cookie = vendor;
      //this.path=this.vendor.image;
    },
      error => {
        this.exception = error.message;
      });
  }
  goBack():void
  {
    this.location.back();
  }
}
