import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '../../../node_modules/@angular/forms';
import { CookiecafeService } from '../cookiecafe.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private cookieservice: CookiecafeService) { }
  cookie: any;
  exception: any;
  //bool:any;
  ngOnInit() {
  }
  cookieForm = new FormGroup({
    cookieId: new FormControl('')
  });
  onSubmit() {
    //this.bool=false;
    this.cookieservice.getCookieOnId(this.cookieForm.value.cookieId).subscribe(data=>{
      this.cookie=data;
      console.log(this.cookie);
    },error=>{
      this.exception="Cookie does not exist";
      console.log(this.exception);   
    })
  }
  // onPress():void
  // {
  //   this.bool=true;
  // }
}
