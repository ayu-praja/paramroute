import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Cookie } from './cookie';

@Injectable({
  providedIn: 'root'
})
export class CookiecafeService {

  cookie:Cookie;
  constructor(private http:HttpClient) { }
  getCookieOnId(id: number):any {
    return this.http.get("http://localhost:8080/getcookie/"+id);
  }
  addCookie(cookie:Cookie,cafeId:number):any
  {
    this.cookie=cookie;
    return this.http.post("http://localhost:8080/addcookie/"+cafeId,this.cookie);
  }
  getCafes():any
  {
    return this.http.get("http://localhost:8080/getcafes");
  }
  getCooky(cafeId:number):any{
    return this.http.get("http://localhost:8080/getcooky/"+cafeId);
  }
  deleteCookie(cookieId:number)
  {
    return this.http.delete("http://localhost:8080/deletecookie/"+cookieId);
  }
}
