import { Cookie } from './cookie';

describe('Cookie', () => {
  it('should create an instance', () => {
    expect(new Cookie()).toBeTruthy();
  });
});
