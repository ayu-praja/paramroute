import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './search/search.component';
import { DeleteComponent } from './delete/delete.component';
import { AddComponent } from './add/add.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DisplayComponent } from './display/display.component';

const routes: Routes = [
  { path: 'add', component:AddComponent },
  { path: 'delete', component:DeleteComponent  },
  { path: 'search', component:SearchComponent },
  { path: 'display/:id', component:DisplayComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
