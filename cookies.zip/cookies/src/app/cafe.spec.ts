import { Cafe } from './cafe';

describe('Cafe', () => {
  it('should create an instance', () => {
    expect(new Cafe()).toBeTruthy();
  });
});
