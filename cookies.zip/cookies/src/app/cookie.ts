import { Cafe } from './cafe';

export class Cookie 
{
    cookieId:number;
    cookieName:String;
    cafe:Cafe;
}
