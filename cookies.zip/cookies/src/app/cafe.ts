import { Cookie } from './cookie';

export class Cafe 
{
    cafeId:number;
    cafeName:String;
    cookie:Cookie[];
}
