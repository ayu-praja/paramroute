import { Component, OnInit } from '@angular/core';
import { CookiecafeService } from '../cookiecafe.service';
import { FormGroup, FormControl } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(private cookiecafeService: CookiecafeService) { }
  cafes:any;
  cafeId:any;
  cookies:any;
  exceptions:any;
  msg:any;
  delete=new FormGroup({
    cookiesId:new FormControl(''),
    cafeObject:new FormControl('')
  })
  ngOnInit() {
    this.reload();
  }
  reload():any
  {
    this.cookiecafeService.getCafes().subscribe(data=>{
      this.cafes=data;
    })
  }
  getCafe(event)
  {
    console.log(event);
    this.cafeId=event;
    this.cookiecafeService.getCooky(this.cafeId).subscribe(data=>{
      this.cookies=data;
      console.log(this.cookies.cookieId);
    },
  error=>{
    this.exceptions=error;
  });
  }
  onSubmit()
  {
    this.cookiecafeService.deleteCookie(this.delete.value.cookiesId).subscribe(data=>{
      this.msg=data;
    })
  }

}
