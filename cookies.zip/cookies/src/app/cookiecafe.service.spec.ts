import { TestBed } from '@angular/core/testing';

import { CookiecafeService } from './cookiecafe.service';

describe('CookiecafeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CookiecafeService = TestBed.get(CookiecafeService);
    expect(service).toBeTruthy();
  });
});
