import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '../../../node_modules/@angular/forms';
import { Cookie } from '../cookie';
import { CookiecafeService } from '../cookiecafe.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  cafelist:any;
  constructor(private cookieservice:CookiecafeService) { }
  cookieForm = new FormGroup({
    cookieName: new FormControl(''),
    price: new FormControl(''),
    cafes:new FormControl('')
  });
  cookie:any;
  cookies:any;
  exception:any;
  onSubmit() {
    this.cookie=new Cookie();
    this.cookie.cookieName=this.cookieForm.value.cookieName;
    this.cookie.price=this.cookieForm.value.price;
    this.cookieservice.addCookie(this.cookie,this.cookieForm.value.cafes).subscribe(data=>{
      this.cookies=data;
    },error=>this.exception=error);
  }

  ngOnInit() {
    this.cookieservice.getCafes().subscribe(data=>{
      this.cafelist=data;
    });
  }
}
